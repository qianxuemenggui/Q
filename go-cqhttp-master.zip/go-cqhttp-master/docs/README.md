# 文档

> 文档目前依旧保留以便往前兼容
\
下面的文档更易读以及人性化, 强烈建议您查看下面提供的文档

目前文档已移动到位于 [go-cqhttp-docs](https://github.com/ishkong/go-cqhttp-docs) 的仓库

您可以在以下其中任意一个链接查看:

- <https://docs.go-cqhttp.org>
- <https://ishkong.github.io/go-cqhttp-docs>
